package dev.donam.flinkgs;

import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.connector.source.util.ratelimit.RateLimiterStrategy;
import org.apache.flink.configuration.ConfigurationUtils;
import org.apache.flink.connector.datagen.source.DataGeneratorSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class SimpleJob {
    private static final Logger LOG = LoggerFactory.getLogger(SimpleJob.class);

    public static void main(String[] args) throws Exception {
        var props = new Properties();
        props.put("metrics.reporter.jmx.factory.class", "org.apache.flink.metrics.jmx.JMXReporterFactory");
        var conf = ConfigurationUtils.createConfiguration(props);

        try (var env = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf)) {
            LOG.debug("Start Flink example job");

            var source = new DataGeneratorSource<>(
                index -> index,
                Long.MAX_VALUE,
                RateLimiterStrategy.perSecond(1),
                Types.LONG
            );

            var ds = env.fromSource(
                source,
                WatermarkStrategy.noWatermarks(),
                "NumberGen"
            );
            ds.filter(e -> e % 2 == 0).print();

            env.execute("Simple Job");
        }
    }
}
