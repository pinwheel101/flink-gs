# Flink v2 Getting Started

## Gradle

```bash
 ./gradlew --configuration-cache
```