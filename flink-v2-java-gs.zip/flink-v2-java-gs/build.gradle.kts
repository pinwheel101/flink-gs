plugins {
    id("java")
    id("application")
    id("com.gradleup.shadow") version "9.2.2"
}

group = "org.example"
version = "1.0-SNAPSHOT"
description = "flink v2 getting started"

// versions
val javaVersion = "17"
val flinkVersion = "2.1.0"
val scalaBinaryVersion = "_2.12"
val slf4jVersion = "1.7.36"
val log4jVersion = "2.24.3"

java {
    sourceCompatibility = JavaVersion.toVersion(javaVersion)
    targetCompatibility = JavaVersion.toVersion(javaVersion)
    toolchain {
         languageVersion.set(JavaLanguageVersion.of(javaVersion))
    }
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
}

application {
//    mainClass.set("org.quickstart.DataStreamJob")
    applicationDefaultJvmArgs = listOf("-Dlog4j.configurationFile=log4j2.properties")
}

repositories {
    mavenCentral()
}

val flinkShadowJar by configurations.creating {
    exclude(group = "org.apache.flink", module = "force-shading")
    exclude(group = "com.google.code.findbugs", module = "jsr305")
    exclude(group = "org.slf4j")
    exclude(group = "org.apache.logging.log4j")
}

dependencies {
    // Flink가 제공하는 라이브러리: 쉐도우 JAR 포함 대상 아님
    implementation("org.apache.flink:flink-streaming-java:$flinkVersion")
    implementation("org.apache.flink:flink-clients:$flinkVersion")
    implementation("org.apache.flink:flink-runtime-web:${flinkVersion}")
    implementation("org.apache.flink:flink-metrics-jmx:${flinkVersion}")
    // 커넥터 등 쉐도우 JAR에 포함해야 하는 의존성은 flinkShadowJar에 추가
    // add("flinkShadowJar", "org.apache.flink:flink-connector-kafka:$flinkVersion")

    runtimeOnly("org.apache.logging.log4j:log4j-slf4j-impl:$log4jVersion")
    runtimeOnly("org.apache.logging.log4j:log4j-api:$log4jVersion")
    runtimeOnly("org.apache.logging.log4j:log4j-core:$log4jVersion")

    testImplementation("org.apache.flink:flink-test-utils:$flinkVersion")
}

sourceSets {
    named("main") {
        compileClasspath += flinkShadowJar
        runtimeClasspath += flinkShadowJar
    }
    named("test") {
        compileClasspath += flinkShadowJar
        runtimeClasspath += flinkShadowJar
    }
}

// Javadoc 작업에 flinkShadowJar 클래스패스 추가
tasks.withType<Javadoc> {
    classpath = classpath.plus(flinkShadowJar)
}

// run 작업의 클래스패스 보강 (application 플러그인 제공 run 재설정)
tasks.named<JavaExec>("run") {
    classpath = sourceSets["main"].runtimeClasspath
}

tasks.jar {
    manifest {
        attributes(
            mapOf(
                "Built-By" to System.getProperty("user.name"),
                "Build-Jdk" to System.getProperty("java.version")
            )
        )
    }
}

// Shadow JAR에 포함할 구성 지정
tasks.named<com.github.jengelman.gradle.plugins.shadow.tasks.ShadowJar>("shadowJar") {
    configurations = listOf(flinkShadowJar)
}