package com.flink.perf;

import com.flink.streaming.avro.Event;
import com.flink.streaming.avro.EventType;
import com.flink.streaming.avro.Metadata;

import java.util.*;

/**
 * Generates test data for performance benchmarking.
 */
public class DataGenerator {

    private static final Random RANDOM = new Random(42); // Fixed seed for reproducibility
    private static final EventType[] EVENT_TYPES = EventType.values();

    /**
     * Generate a list of random events for testing.
     *
     * @param count number of events to generate
     * @return list of generated events
     */
    public static List<Event> generate(int count) {
        List<Event> events = new ArrayList<>(count);

        for (int i = 0; i < count; i++) {
            Event event = generateEvent(i);
            events.add(event);
        }

        return events;
    }

    /**
     * Generate a single random event.
     *
     * @param index event index
     * @return generated event
     */
    private static Event generateEvent(int index) {
        Event.Builder builder = Event.newBuilder();

        // Basic fields
        builder.setEventId(UUID.randomUUID().toString());
        builder.setTimestamp(System.currentTimeMillis() - RANDOM.nextInt(86400000)); // Random time within last day
        builder.setUserId("user_" + RANDOM.nextInt(10000));
        builder.setEventType(EVENT_TYPES[RANDOM.nextInt(EVENT_TYPES.length)]);

        // Payload (random key-value pairs)
        Map<CharSequence, CharSequence> payload = new HashMap<>();
        int payloadSize = 3 + RANDOM.nextInt(5); // 3-7 entries
        for (int i = 0; i < payloadSize; i++) {
            payload.put("key_" + i, "value_" + RANDOM.nextInt(1000));
        }
        builder.setPayload(payload);

        // Metadata (50% chance)
        if (RANDOM.nextBoolean()) {
            Metadata.Builder metadataBuilder = Metadata.newBuilder();
            metadataBuilder.setSource("source_" + RANDOM.nextInt(10));
            metadataBuilder.setVersion("v1.0." + RANDOM.nextInt(10));
            if (RANDOM.nextBoolean()) {
                metadataBuilder.setIpAddress("192.168." + RANDOM.nextInt(256) + "." + RANDOM.nextInt(256));
            }
            builder.setMetadata(metadataBuilder.build());
        }

        // Session ID (70% chance)
        if (RANDOM.nextDouble() < 0.7) {
            builder.setSessionId("session_" + RANDOM.nextInt(1000));
        }

        return builder.build();
    }
}
