package com.flink.perf;

/**
 * Analyzes and formats benchmark results for presentation.
 */
public class ResultAnalyzer {

    public static void printResults(AvroVsJsonBenchmark.BenchmarkResult result, int recordCount) {
        System.out.println();
        System.out.println("Data Size Comparison:");
        System.out.println("-".repeat(80));
        System.out.printf("  Avro:  %,d bytes (%.2f MB)%n", result.avroDataSize,
                result.avroDataSize / (1024.0 * 1024.0));
        System.out.printf("  JSON:  %,d bytes (%.2f MB)%n", result.jsonDataSize,
                result.jsonDataSize / (1024.0 * 1024.0));
        System.out.printf("  Ratio: %.2fx smaller (%.1f%% size reduction)%n",
                (double) result.jsonDataSize / result.avroDataSize,
                100.0 * (1 - (double) result.avroDataSize / result.jsonDataSize));

        System.out.println();
        System.out.println("Serialization Performance:");
        System.out.println("-".repeat(80));
        double avroSerMs = result.avroSerializationNanos / 1_000_000.0;
        double jsonSerMs = result.jsonSerializationNanos / 1_000_000.0;
        System.out.printf("  Avro:  %.2f ms (%.0f records/sec)%n",
                avroSerMs, recordCount / (avroSerMs / 1000.0));
        System.out.printf("  JSON:  %.2f ms (%.0f records/sec)%n",
                jsonSerMs, recordCount / (jsonSerMs / 1000.0));
        System.out.printf("  Ratio: %.2fx faster%n", jsonSerMs / avroSerMs);

        System.out.println();
        System.out.println("Deserialization Performance:");
        System.out.println("-".repeat(80));
        double avroDeserMs = result.avroDeserializationNanos / 1_000_000.0;
        double jsonDeserMs = result.jsonDeserializationNanos / 1_000_000.0;
        System.out.printf("  Avro:  %.2f ms (%.0f records/sec)%n",
                avroDeserMs, recordCount / (avroDeserMs / 1000.0));
        System.out.printf("  JSON:  %.2f ms (%.0f records/sec)%n",
                jsonDeserMs, recordCount / (jsonDeserMs / 1000.0));
        System.out.printf("  Ratio: %.2fx faster%n", jsonDeserMs / avroDeserMs);

        System.out.println();
        System.out.println("Total Processing Time:");
        System.out.println("-".repeat(80));
        double avroTotalMs = avroSerMs + avroDeserMs;
        double jsonTotalMs = jsonSerMs + jsonDeserMs;
        System.out.printf("  Avro:  %.2f ms%n", avroTotalMs);
        System.out.printf("  JSON:  %.2f ms%n", jsonTotalMs);
        System.out.printf("  Ratio: %.2fx faster%n", jsonTotalMs / avroTotalMs);

        System.out.println();
        System.out.println("Summary:");
        System.out.println("-".repeat(80));
        System.out.printf("  Avro is %.2fx more space-efficient than JSON%n",
                (double) result.jsonDataSize / result.avroDataSize);
        System.out.printf("  Avro serialization is %.2fx faster than JSON%n",
                jsonSerMs / avroSerMs);
        System.out.printf("  Avro deserialization is %.2fx faster than JSON%n",
                jsonDeserMs / avroDeserMs);
        System.out.printf("  Overall, Avro is %.2fx faster than JSON%n",
                jsonTotalMs / avroTotalMs);

        System.out.println();
        System.out.println("Conclusion:");
        System.out.println("-".repeat(80));
        System.out.println("  For streaming pipelines processing millions of events:");
        System.out.printf("  - Network bandwidth savings: %.1f%%%n",
                100.0 * (1 - (double) result.avroDataSize / result.jsonDataSize));
        System.out.printf("  - Storage savings: %.1f%%%n",
                100.0 * (1 - (double) result.avroDataSize / result.jsonDataSize));
        System.out.printf("  - Processing time reduction: %.1f%%%n",
                100.0 * (1 - avroTotalMs / jsonTotalMs));
        System.out.println();
        System.out.println("  ✓ Avro is the clear winner for production streaming workloads!");
        System.out.println("=".repeat(80));
    }
}
