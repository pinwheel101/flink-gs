package com.flink.perf;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.flink.streaming.avro.Event;
import org.apache.avro.io.*;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.avro.specific.SpecificDatumWriter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

/**
 * Benchmark comparing Avro vs JSON serialization performance.
 *
 * Measures:
 * - Serialization time
 * - Deserialization time
 * - Data size
 * - Throughput
 */
public class AvroVsJsonBenchmark {

    private static final int RECORD_COUNT = 100_000;
    private static final int WARMUP_ITERATIONS = 3;
    private static final int BENCHMARK_ITERATIONS = 5;

    public static void main(String[] args) throws Exception {
        System.out.println("=".repeat(80));
        System.out.println("Avro vs JSON Performance Benchmark");
        System.out.println("=".repeat(80));
        System.out.println("Record count: " + RECORD_COUNT);
        System.out.println("Warmup iterations: " + WARMUP_ITERATIONS);
        System.out.println("Benchmark iterations: " + BENCHMARK_ITERATIONS);
        System.out.println();

        // Generate test data
        System.out.println("Generating test data...");
        List<Event> events = DataGenerator.generate(RECORD_COUNT);
        System.out.println("Generated " + events.size() + " events");
        System.out.println();

        // Warmup
        System.out.println("Warming up...");
        for (int i = 0; i < WARMUP_ITERATIONS; i++) {
            runBenchmark(events, false);
        }
        System.out.println("Warmup complete");
        System.out.println();

        // Run actual benchmark
        System.out.println("Running benchmark...");
        BenchmarkResult totalResult = new BenchmarkResult();

        for (int i = 0; i < BENCHMARK_ITERATIONS; i++) {
            System.out.println("Iteration " + (i + 1) + "/" + BENCHMARK_ITERATIONS);
            BenchmarkResult result = runBenchmark(events, true);
            totalResult.add(result);
        }

        // Calculate averages
        totalResult.average(BENCHMARK_ITERATIONS);

        // Print results
        System.out.println();
        System.out.println("=".repeat(80));
        System.out.println("RESULTS");
        System.out.println("=".repeat(80));
        ResultAnalyzer.printResults(totalResult, RECORD_COUNT);
    }

    private static BenchmarkResult runBenchmark(List<Event> events, boolean print) throws Exception {
        BenchmarkResult result = new BenchmarkResult();

        // Avro Serialization
        long avroSerStart = System.nanoTime();
        byte[] avroData = serializeAvro(events);
        long avroSerTime = System.nanoTime() - avroSerStart;
        result.avroSerializationNanos = avroSerTime;
        result.avroDataSize = avroData.length;

        // JSON Serialization
        long jsonSerStart = System.nanoTime();
        byte[] jsonData = serializeJson(events);
        long jsonSerTime = System.nanoTime() - jsonSerStart;
        result.jsonSerializationNanos = jsonSerTime;
        result.jsonDataSize = jsonData.length;

        // Avro Deserialization
        long avroDeserStart = System.nanoTime();
        List<Event> avroEvents = deserializeAvro(avroData, events.size());
        long avroDeserTime = System.nanoTime() - avroDeserStart;
        result.avroDeserializationNanos = avroDeserTime;

        // JSON Deserialization
        long jsonDeserStart = System.nanoTime();
        String jsonStr = new String(jsonData);
        long jsonDeserTime = System.nanoTime() - jsonDeserStart;
        result.jsonDeserializationNanos = jsonDeserTime;

        if (print) {
            System.out.println("  Avro: ser=" + formatTime(avroSerTime) +
                             ", deser=" + formatTime(avroDeserTime) +
                             ", size=" + formatSize(avroData.length));
            System.out.println("  JSON: ser=" + formatTime(jsonSerTime) +
                             ", deser=" + formatTime(jsonDeserTime) +
                             ", size=" + formatSize(jsonData.length));
        }

        return result;
    }

    private static byte[] serializeAvro(List<Event> events) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        Encoder encoder = EncoderFactory.get().binaryEncoder(outputStream, null);
        DatumWriter<Event> writer = new SpecificDatumWriter<>(Event.class);

        for (Event event : events) {
            writer.write(event, encoder);
        }
        encoder.flush();

        return outputStream.toByteArray();
    }

    private static List<Event> deserializeAvro(byte[] data, int count) throws IOException {
        Decoder decoder = DecoderFactory.get().binaryDecoder(data, null);
        DatumReader<Event> reader = new SpecificDatumReader<>(Event.class);

        List<Event> events = new java.util.ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            events.add(reader.read(null, decoder));
        }

        return events;
    }

    private static byte[] serializeJson(List<Event> events) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsBytes(events);
    }

    private static String formatTime(long nanos) {
        return String.format("%.2fms", nanos / 1_000_000.0);
    }

    private static String formatSize(int bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        } else if (bytes < 1024 * 1024) {
            return String.format("%.2f KB", bytes / 1024.0);
        } else {
            return String.format("%.2f MB", bytes / (1024.0 * 1024.0));
        }
    }

    static class BenchmarkResult {
        long avroSerializationNanos;
        long avroDeserializationNanos;
        long jsonSerializationNanos;
        long jsonDeserializationNanos;
        long avroDataSize;
        long jsonDataSize;

        void add(BenchmarkResult other) {
            this.avroSerializationNanos += other.avroSerializationNanos;
            this.avroDeserializationNanos += other.avroDeserializationNanos;
            this.jsonSerializationNanos += other.jsonSerializationNanos;
            this.jsonDeserializationNanos += other.jsonDeserializationNanos;
            this.avroDataSize += other.avroDataSize;
            this.jsonDataSize += other.jsonDataSize;
        }

        void average(int count) {
            this.avroSerializationNanos /= count;
            this.avroDeserializationNanos /= count;
            this.jsonSerializationNanos /= count;
            this.jsonDeserializationNanos /= count;
            this.avroDataSize /= count;
            this.jsonDataSize /= count;
        }
    }
}
