package com.flink.streaming.source;

import com.flink.streaming.avro.Event;
import org.apache.avro.io.BinaryDecoder;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Custom deserialization schema for Avro events from Kafka.
 * Provides efficient binary deserialization with error handling.
 */
public class AvroDeserializationSchema implements DeserializationSchema<Event> {
    private static final Logger LOG = LoggerFactory.getLogger(AvroDeserializationSchema.class);

    private transient DatumReader<Event> reader;
    private transient BinaryDecoder decoder;

    @Override
    public void open(InitializationContext context) throws Exception {
        this.reader = new SpecificDatumReader<>(Event.class);
        LOG.info("Avro deserialization schema initialized");
    }

    @Override
    public Event deserialize(byte[] message) throws IOException {
        if (message == null || message.length == 0) {
            LOG.warn("Received null or empty message");
            return null;
        }

        try {
            decoder = DecoderFactory.get().binaryDecoder(message, decoder);
            Event event = reader.read(null, decoder);
            return event;
        } catch (Exception e) {
            LOG.error("Failed to deserialize Avro message", e);
            // In production, you might want to send to dead letter queue
            return null;
        }
    }

    @Override
    public boolean isEndOfStream(Event nextElement) {
        return false;
    }

    @Override
    public TypeInformation<Event> getProducedType() {
        return TypeInformation.of(Event.class);
    }
}
