package com.flink.streaming.catalog;

import com.flink.streaming.config.CatalogConfig;
import org.apache.iceberg.catalog.Catalog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Factory for creating Iceberg catalogs based on configuration.
 * Supports multiple catalog types (Hive Metastore, REST) with zero-code migration.
 */
public class CatalogFactory {
    private static final Logger LOG = LoggerFactory.getLogger(CatalogFactory.class);

    /**
     * Creates an Iceberg catalog based on the provided configuration.
     *
     * @param config the catalog configuration
     * @return configured Iceberg catalog
     * @throws IllegalArgumentException if catalog type is unsupported
     */
    public static Catalog createCatalog(CatalogConfig config) {
        LOG.info("Creating catalog of type: {}", config.getType());

        switch (config.getType()) {
            case HIVE:
                return new HiveCatalogProvider(config).create();
            case REST:
                return new RestCatalogProvider(config).create();
            default:
                throw new IllegalArgumentException("Unsupported catalog type: " + config.getType());
        }
    }
}
