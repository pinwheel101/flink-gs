package com.flink.streaming.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Main application configuration class that loads and validates all configuration properties.
 */
public class AppConfig {
    private static final Logger LOG = LoggerFactory.getLogger(AppConfig.class);
    private static final String DEFAULT_CONFIG_FILE = "application.properties";

    private final Properties properties;
    private final KafkaConfig kafkaConfig;
    private final IcebergConfig icebergConfig;
    private final CatalogConfig catalogConfig;

    public AppConfig() {
        this(DEFAULT_CONFIG_FILE);
    }

    public AppConfig(String configPath) {
        this.properties = loadProperties(configPath);
        validateConfiguration();

        this.kafkaConfig = new KafkaConfig(properties);
        this.icebergConfig = new IcebergConfig(properties);
        this.catalogConfig = new CatalogConfig(properties);

        LOG.info("Application configuration loaded successfully");
    }

    private Properties loadProperties(String configPath) {
        Properties props = new Properties();
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(configPath)) {
            if (input == null) {
                throw new IllegalArgumentException("Unable to find " + configPath);
            }
            props.load(input);
            LOG.info("Loaded configuration from: {}", configPath);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load configuration from: " + configPath, e);
        }
        return props;
    }

    private void validateConfiguration() {
        // Validate required properties
        requireProperty("kafka.bootstrap.servers");
        requireProperty("kafka.topic");
        requireProperty("catalog.type");
        requireProperty("catalog.warehouse");
        requireProperty("iceberg.table.name");

        // Validate catalog-specific properties
        String catalogType = properties.getProperty("catalog.type");
        if ("hive".equalsIgnoreCase(catalogType)) {
            requireProperty("hive.metastore.uri");
        } else if ("rest".equalsIgnoreCase(catalogType)) {
            requireProperty("rest.catalog.uri");
        }

        LOG.info("Configuration validation passed");
    }

    private void requireProperty(String key) {
        if (!properties.containsKey(key) || properties.getProperty(key).trim().isEmpty()) {
            throw new IllegalArgumentException("Required property missing or empty: " + key);
        }
    }

    public String getProperty(String key) {
        return properties.getProperty(key);
    }

    public String getProperty(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

    public int getIntProperty(String key, int defaultValue) {
        String value = properties.getProperty(key);
        if (value == null) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            LOG.warn("Invalid integer value for {}: {}. Using default: {}", key, value, defaultValue);
            return defaultValue;
        }
    }

    public long getLongProperty(String key, long defaultValue) {
        String value = properties.getProperty(key);
        if (value == null) {
            return defaultValue;
        }
        try {
            return Long.parseLong(value.trim());
        } catch (NumberFormatException e) {
            LOG.warn("Invalid long value for {}: {}. Using default: {}", key, value, defaultValue);
            return defaultValue;
        }
    }

    public boolean getBooleanProperty(String key, boolean defaultValue) {
        String value = properties.getProperty(key);
        if (value == null) {
            return defaultValue;
        }
        return Boolean.parseBoolean(value.trim());
    }

    public KafkaConfig getKafkaConfig() {
        return kafkaConfig;
    }

    public IcebergConfig getIcebergConfig() {
        return icebergConfig;
    }

    public CatalogConfig getCatalogConfig() {
        return catalogConfig;
    }

    public Properties getProperties() {
        return new Properties(properties);
    }
}
