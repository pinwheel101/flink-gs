package com.flink.streaming.transform;

import com.flink.streaming.avro.Event;
import com.flink.streaming.avro.EventType;
import com.flink.streaming.avro.Metadata;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.table.data.GenericRowData;
import org.apache.flink.table.data.RowData;
import org.apache.flink.table.data.StringData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * Default transformation that converts Avro Event objects to Flink RowData.
 * This implementation provides a simple mapping that can be customized.
 */
public class DefaultTransformation implements TransformationPipeline {
    private static final Logger LOG = LoggerFactory.getLogger(DefaultTransformation.class);

    @Override
    public DataStream<RowData> transform(DataStream<Event> source) {
        LOG.info("Applying default transformation pipeline");

        return source
                .filter(event -> event != null && event.getEventId() != null)
                .map(new EventToRowDataMapper())
                .name("avro-to-rowdata");
    }

    @Override
    public String getName() {
        return "DefaultTransformation";
    }

    /**
     * Mapper function that converts Avro Event to Flink RowData.
     */
    private static class EventToRowDataMapper implements MapFunction<Event, RowData> {
        @Override
        public RowData map(Event event) throws Exception {
            GenericRowData row = new GenericRowData(7);

            // Field 0: event_id
            row.setField(0, StringData.fromString(event.getEventId().toString()));

            // Field 1: timestamp
            row.setField(1, event.getTimestamp());

            // Field 2: user_id
            row.setField(2, StringData.fromString(event.getUserId().toString()));

            // Field 3: event_type
            EventType eventType = event.getEventType();
            row.setField(3, StringData.fromString(eventType != null ? eventType.toString() : "UNKNOWN"));

            // Field 4: payload (convert Map to string for simplicity)
            Map<CharSequence, CharSequence> payload = event.getPayload();
            String payloadStr = payload != null ? payload.toString() : "{}";
            row.setField(4, StringData.fromString(payloadStr));

            // Field 5: metadata source (nested field extraction)
            Metadata metadata = event.getMetadata();
            if (metadata != null && metadata.getSource() != null) {
                row.setField(5, StringData.fromString(metadata.getSource().toString()));
            } else {
                row.setField(5, null);
            }

            // Field 6: session_id
            CharSequence sessionId = event.getSessionId();
            if (sessionId != null) {
                row.setField(6, StringData.fromString(sessionId.toString()));
            } else {
                row.setField(6, null);
            }

            return row;
        }
    }
}
