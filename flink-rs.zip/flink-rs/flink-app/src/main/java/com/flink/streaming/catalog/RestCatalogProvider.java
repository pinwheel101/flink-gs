package com.flink.streaming.catalog;

import com.flink.streaming.config.CatalogConfig;
import org.apache.hadoop.conf.Configuration;
import org.apache.iceberg.CatalogUtil;
import org.apache.iceberg.catalog.Catalog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Provider for REST-based Iceberg catalog (e.g., Polaris, Nessie).
 */
public class RestCatalogProvider {
    private static final Logger LOG = LoggerFactory.getLogger(RestCatalogProvider.class);
    private final CatalogConfig config;

    public RestCatalogProvider(CatalogConfig config) {
        this.config = config;
    }

    public Catalog create() {
        LOG.info("Creating REST catalog with URI: {}", config.getRestUri());

        Map<String, String> properties = new HashMap<>();
        properties.put("type", "rest");
        properties.put("uri", config.getRestUri());
        properties.put("warehouse", config.getRestWarehouse());

        // Add credentials if provided
        if (config.getRestCredential() != null && !config.getRestCredential().isEmpty()) {
            properties.put("credential", config.getRestCredential());
            LOG.info("REST catalog credential configured");
        }

        // Additional REST catalog properties
        properties.put("clients", "5");
        properties.put("io-impl", "org.apache.iceberg.aws.s3.S3FileIO");

        Configuration hadoopConf = new Configuration();

        Catalog catalog = CatalogUtil.buildIcebergCatalog(
            config.getName(),
            properties,
            hadoopConf
        );

        LOG.info("REST catalog created successfully: {}", config.getName());
        return catalog;
    }
}
