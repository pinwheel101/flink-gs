package com.flink.streaming.config;

import java.util.Properties;

/**
 * Kafka-specific configuration.
 */
public class KafkaConfig {
    private final String bootstrapServers;
    private final String topic;
    private final String groupId;
    private final String securityProtocol;
    private final String autoOffsetReset;

    public KafkaConfig(Properties properties) {
        this.bootstrapServers = properties.getProperty("kafka.bootstrap.servers");
        this.topic = properties.getProperty("kafka.topic");
        this.groupId = properties.getProperty("kafka.group.id", "flink-consumer-group");
        this.securityProtocol = properties.getProperty("kafka.security.protocol", "PLAINTEXT");
        this.autoOffsetReset = properties.getProperty("kafka.auto.offset.reset", "earliest");
    }

    public String getBootstrapServers() {
        return bootstrapServers;
    }

    public String getTopic() {
        return topic;
    }

    public String getGroupId() {
        return groupId;
    }

    public String getSecurityProtocol() {
        return securityProtocol;
    }

    public String getAutoOffsetReset() {
        return autoOffsetReset;
    }

    public Properties toKafkaProperties() {
        Properties kafkaProps = new Properties();
        kafkaProps.setProperty("bootstrap.servers", bootstrapServers);
        kafkaProps.setProperty("group.id", groupId);
        kafkaProps.setProperty("security.protocol", securityProtocol);
        kafkaProps.setProperty("auto.offset.reset", autoOffsetReset);
        kafkaProps.setProperty("enable.auto.commit", "false");
        kafkaProps.setProperty("isolation.level", "read_committed");
        return kafkaProps;
    }

    @Override
    public String toString() {
        return "KafkaConfig{" +
                "bootstrapServers='" + bootstrapServers + '\'' +
                ", topic='" + topic + '\'' +
                ", groupId='" + groupId + '\'' +
                ", securityProtocol='" + securityProtocol + '\'' +
                ", autoOffsetReset='" + autoOffsetReset + '\'' +
                '}';
    }
}
