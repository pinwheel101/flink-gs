package com.flink.streaming.transform;

import com.flink.streaming.avro.Event;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.table.data.RowData;

import java.io.Serializable;

/**
 * Interface for transformation pipelines.
 * Allows easy swapping of transformation logic without changing core application code.
 */
public interface TransformationPipeline extends Serializable {

    /**
     * Transform the input stream of Avro events to RowData for Iceberg.
     *
     * @param source the input DataStream of Event objects
     * @return transformed DataStream of RowData
     */
    DataStream<RowData> transform(DataStream<Event> source);

    /**
     * Get the name of this transformation pipeline.
     *
     * @return transformation pipeline name
     */
    String getName();
}
