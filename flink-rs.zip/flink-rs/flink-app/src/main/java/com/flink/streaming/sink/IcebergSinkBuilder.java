package com.flink.streaming.sink;

import com.flink.streaming.config.CatalogConfig;
import com.flink.streaming.config.IcebergConfig;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSink;
import org.apache.flink.table.data.RowData;
import org.apache.flink.table.types.logical.BigIntType;
import org.apache.flink.table.types.logical.RowType;
import org.apache.flink.table.types.logical.VarCharType;
import org.apache.iceberg.catalog.Catalog;
import org.apache.iceberg.catalog.Namespace;
import org.apache.iceberg.catalog.TableIdentifier;
import org.apache.iceberg.flink.FlinkSchemaUtil;
import org.apache.iceberg.flink.TableLoader;
import org.apache.iceberg.flink.sink.FlinkSink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;

/**
 * Builder for creating Iceberg sink.
 * Uses the Dynamic Iceberg Sink available in Flink 2.x.
 */
public class IcebergSinkBuilder {
    private static final Logger LOG = LoggerFactory.getLogger(IcebergSinkBuilder.class);

    private final Catalog catalog;
    private final CatalogConfig catalogConfig;
    private final IcebergConfig icebergConfig;

    public IcebergSinkBuilder(Catalog catalog, CatalogConfig catalogConfig, IcebergConfig icebergConfig) {
        this.catalog = catalog;
        this.catalogConfig = catalogConfig;
        this.icebergConfig = icebergConfig;
    }

    /**
     * Builds and returns an Iceberg sink for the configured table.
     *
     * @param stream the input DataStream of RowData
     * @return configured DataStreamSink
     */
    public DataStreamSink<RowData> buildSink(DataStream<RowData> stream) {
        LOG.info("Building Iceberg sink for table: {}.{}.{}",
                catalogConfig.getName(),
                catalogConfig.getDatabase(),
                icebergConfig.getTableName());

        // Create table identifier
        TableIdentifier tableId = TableIdentifier.of(
                Namespace.of(catalogConfig.getDatabase()),
                icebergConfig.getTableName()
        );

        // Ensure table exists
        ensureTableExists(tableId);

        // Create table loader
        TableLoader tableLoader = TableLoader.fromCatalog(
                new org.apache.iceberg.flink.CatalogLoader() {
                    @Override
                    public Catalog loadCatalog() {
                        return catalog;
                    }
                },
                tableId
        );

        // Build the sink
        FlinkSink.Builder builder = FlinkSink.forRowData(stream)
                .tableLoader(tableLoader)
                .writeParallelism(icebergConfig.getWriteParallelism())
                .uidPrefix("iceberg-sink-" + icebergConfig.getTableName());

        // Configure upsert mode if enabled
        if (icebergConfig.isUpsertMode()) {
            LOG.info("Configuring Iceberg sink in upsert mode");
            builder.upsert(true);
            builder.equalityFieldColumns(Arrays.asList("event_id"));
        }

        DataStreamSink<RowData> sink = builder.append();

        LOG.info("Iceberg sink created successfully");
        return sink;
    }

    /**
     * Ensures the Iceberg table exists, creating it if necessary.
     *
     * @param tableId the table identifier
     */
    private void ensureTableExists(TableIdentifier tableId) {
        try {
            if (!catalog.tableExists(tableId)) {
                LOG.info("Table does not exist, creating: {}", tableId);
                createTable(tableId);
            } else {
                LOG.info("Table already exists: {}", tableId);
            }
        } catch (Exception e) {
            LOG.error("Failed to check/create table: {}", tableId, e);
            throw new RuntimeException("Failed to ensure table exists: " + tableId, e);
        }
    }

    /**
     * Creates the Iceberg table with the appropriate schema.
     *
     * @param tableId the table identifier
     */
    private void createTable(TableIdentifier tableId) {
        // Define Flink row type matching our Event schema
        RowType rowType = RowType.of(
                new VarCharType(VarCharType.MAX_LENGTH),  // event_id
                new BigIntType(),                          // timestamp
                new VarCharType(VarCharType.MAX_LENGTH),  // user_id
                new VarCharType(VarCharType.MAX_LENGTH),  // event_type
                new VarCharType(VarCharType.MAX_LENGTH),  // payload
                new VarCharType(VarCharType.MAX_LENGTH),  // metadata_source
                new VarCharType(VarCharType.MAX_LENGTH)   // session_id
        );

        rowType = (RowType) rowType.copy(true);  // Make nullable

        // Field names
        String[] fieldNames = new String[]{
                "event_id",
                "timestamp",
                "user_id",
                "event_type",
                "payload",
                "metadata_source",
                "session_id"
        };

        rowType = RowType.of(
                rowType.getChildren().toArray(new org.apache.flink.table.types.logical.LogicalType[0]),
                fieldNames
        );

        // Convert to Iceberg schema
        org.apache.iceberg.Schema icebergSchema = FlinkSchemaUtil.convert(rowType);

        // Create table
        catalog.createTable(tableId, icebergSchema);

        LOG.info("Created Iceberg table: {} with schema: {}", tableId, icebergSchema);
    }
}
