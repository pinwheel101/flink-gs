package com.flink.streaming;

import com.flink.streaming.avro.Event;
import com.flink.streaming.catalog.CatalogFactory;
import com.flink.streaming.config.AppConfig;
import com.flink.streaming.sink.IcebergSinkBuilder;
import com.flink.streaming.source.KafkaSourceBuilder;
import com.flink.streaming.transform.DefaultTransformation;
import com.flink.streaming.transform.TransformationPipeline;
import org.apache.flink.api.common.RuntimeExecutionMode;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.contrib.streaming.state.EmbeddedRocksDBStateBackend;
import org.apache.flink.runtime.state.storage.FileSystemCheckpointStorage;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.data.RowData;
import org.apache.iceberg.catalog.Catalog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

/**
 * Main Flink streaming application for Kafka to Iceberg pipeline.
 *
 * This application:
 * 1. Reads Avro events from Kafka
 * 2. Applies transformations
 * 3. Writes to Apache Iceberg tables
 *
 * Features:
 * - Exactly-once processing semantics
 * - RocksDB state backend for large state
 * - Automatic checkpointing
 * - Catalog abstraction (Hive/REST)
 * - Schema evolution support
 */
public class FlinkStreamingApp {
    private static final Logger LOG = LoggerFactory.getLogger(FlinkStreamingApp.class);

    public static void main(String[] args) throws Exception {
        LOG.info("Starting Flink Kafka to Iceberg Streaming Application");

        // Load configuration
        AppConfig config = new AppConfig();
        LOG.info("Configuration loaded: Kafka={}, Catalog={}, Iceberg={}",
                config.getKafkaConfig(),
                config.getCatalogConfig(),
                config.getIcebergConfig());

        // Create execution environment
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // Configure execution mode
        env.setRuntimeMode(RuntimeExecutionMode.STREAMING);

        // Configure parallelism
        int parallelism = config.getIntProperty("flink.parallelism.default", 4);
        int maxParallelism = config.getIntProperty("flink.max.parallelism", 128);
        env.setParallelism(parallelism);
        env.setMaxParallelism(maxParallelism);
        LOG.info("Parallelism configured: default={}, max={}", parallelism, maxParallelism);

        // Configure checkpointing
        configureCheckpointing(env, config);

        // Configure state backend
        configureStateBackend(env, config);

        // Configure restart strategy
        configureRestartStrategy(env, config);

        // Build Kafka source
        KafkaSourceBuilder kafkaBuilder = new KafkaSourceBuilder(config.getKafkaConfig());
        KafkaSource<Event> kafkaSource = kafkaBuilder.build();

        // Create Kafka source stream with watermarks
        DataStream<Event> eventStream = env
                .fromSource(
                        kafkaSource,
                        KafkaSourceBuilder.createWatermarkStrategy(),
                        "Kafka Source"
                )
                .uid("kafka-source");

        LOG.info("Kafka source created for topic: {}", config.getKafkaConfig().getTopic());

        // Create catalog
        Catalog catalog = CatalogFactory.createCatalog(config.getCatalogConfig());
        LOG.info("Catalog created: {}", config.getCatalogConfig());

        // Apply transformation
        TransformationPipeline transformation = new DefaultTransformation();
        DataStream<RowData> transformedStream = transformation.transform(eventStream);
        LOG.info("Transformation pipeline applied: {}", transformation.getName());

        // Build and attach Iceberg sink
        IcebergSinkBuilder sinkBuilder = new IcebergSinkBuilder(
                catalog,
                config.getCatalogConfig(),
                config.getIcebergConfig()
        );
        sinkBuilder.buildSink(transformedStream);

        LOG.info("Iceberg sink configured for table: {}", config.getIcebergConfig().getTableName());

        // Execute the job
        String jobName = config.getProperty("app.name", "Flink Kafka to Iceberg Streaming");
        LOG.info("Executing Flink job: {}", jobName);
        env.execute(jobName);
    }

    /**
     * Configure checkpointing for exactly-once semantics.
     */
    private static void configureCheckpointing(StreamExecutionEnvironment env, AppConfig config) {
        long checkpointInterval = config.getLongProperty("flink.checkpoint.interval", 60000L);
        String checkpointDir = config.getProperty("flink.checkpoint.dir", "file:///tmp/flink/checkpoints");

        env.enableCheckpointing(checkpointInterval);

        CheckpointConfig checkpointConfig = env.getCheckpointConfig();

        // Set checkpointing mode
        checkpointConfig.setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);

        // Minimum pause between checkpoints
        checkpointConfig.setMinPauseBetweenCheckpoints(30000L);

        // Checkpoint timeout
        checkpointConfig.setCheckpointTimeout(600000L);

        // Allow only one checkpoint at a time
        checkpointConfig.setMaxConcurrentCheckpoints(1);

        // Enable externalized checkpoints
        checkpointConfig.setExternalizedCheckpointCleanup(
                CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION
        );

        // Set checkpoint storage
        checkpointConfig.setCheckpointStorage(new FileSystemCheckpointStorage(checkpointDir));

        LOG.info("Checkpointing configured: interval={}ms, dir={}", checkpointInterval, checkpointDir);
    }

    /**
     * Configure state backend for managing operator state.
     */
    private static void configureStateBackend(StreamExecutionEnvironment env, AppConfig config) {
        String stateBackend = config.getProperty("flink.state.backend", "rocksdb");

        if ("rocksdb".equalsIgnoreCase(stateBackend)) {
            try {
                EmbeddedRocksDBStateBackend rocksDBStateBackend = new EmbeddedRocksDBStateBackend();
                rocksDBStateBackend.setEnableIncrementalCheckpointing(true);
                env.setStateBackend(rocksDBStateBackend);
                LOG.info("State backend configured: RocksDB with incremental checkpointing");
            } catch (Exception e) {
                LOG.error("Failed to configure RocksDB state backend", e);
                throw new RuntimeException("Failed to configure state backend", e);
            }
        } else {
            LOG.info("Using default state backend (HashMapStateBackend)");
        }
    }

    /**
     * Configure restart strategy for job failures.
     */
    private static void configureRestartStrategy(StreamExecutionEnvironment env, AppConfig config) {
        int restartAttempts = config.getIntProperty("flink.restart.attempts", 3);
        long restartDelay = config.getLongProperty("flink.restart.delay", 10000L);

        env.setRestartStrategy(RestartStrategies.fixedDelayRestart(
                restartAttempts,
                Time.of(restartDelay, TimeUnit.MILLISECONDS)
        ));

        LOG.info("Restart strategy configured: fixed delay with {} attempts, {}ms delay",
                restartAttempts, restartDelay);
    }
}
