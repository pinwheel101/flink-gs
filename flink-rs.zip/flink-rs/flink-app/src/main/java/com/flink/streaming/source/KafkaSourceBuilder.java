package com.flink.streaming.source;

import com.flink.streaming.avro.Event;
import com.flink.streaming.config.KafkaConfig;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;

/**
 * Builder for creating Kafka source with Avro deserialization.
 * Configures the source with proper consumer properties and watermark strategy.
 */
public class KafkaSourceBuilder {
    private static final Logger LOG = LoggerFactory.getLogger(KafkaSourceBuilder.class);

    private final KafkaConfig config;

    public KafkaSourceBuilder(KafkaConfig config) {
        this.config = config;
    }

    /**
     * Builds a Kafka source configured for reading Avro events.
     *
     * @return configured KafkaSource for Event objects
     */
    public KafkaSource<Event> build() {
        LOG.info("Building Kafka source for topic: {}", config.getTopic());

        KafkaSource<Event> source = KafkaSource.<Event>builder()
                .setBootstrapServers(config.getBootstrapServers())
                .setTopics(config.getTopic())
                .setGroupId(config.getGroupId())
                .setStartingOffsets(OffsetsInitializer.earliest())
                .setDeserializer(new AvroDeserializationSchema())
                .setProperty("isolation.level", "read_committed")
                .setProperty("enable.auto.commit", "false")
                .setProperty("security.protocol", config.getSecurityProtocol())
                .build();

        LOG.info("Kafka source created successfully");
        return source;
    }

    /**
     * Creates a watermark strategy for event time processing.
     * Allows up to 5 seconds of out-of-orderness.
     *
     * @return WatermarkStrategy for Event objects
     */
    public static WatermarkStrategy<Event> createWatermarkStrategy() {
        return WatermarkStrategy
                .<Event>forBoundedOutOfOrderness(Duration.ofSeconds(5))
                .withTimestampAssigner((event, timestamp) -> event.getTimestamp())
                .withIdleness(Duration.ofMinutes(1));
    }
}
