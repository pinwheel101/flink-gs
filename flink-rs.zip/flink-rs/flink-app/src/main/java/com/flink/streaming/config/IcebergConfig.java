package com.flink.streaming.config;

import java.util.Properties;

/**
 * Iceberg table configuration.
 */
public class IcebergConfig {
    private final String tableName;
    private final int writeParallelism;
    private final boolean upsertMode;

    public IcebergConfig(Properties properties) {
        this.tableName = properties.getProperty("iceberg.table.name");
        this.writeParallelism = Integer.parseInt(
            properties.getProperty("iceberg.write.parallelism", "4")
        );
        this.upsertMode = Boolean.parseBoolean(
            properties.getProperty("iceberg.upsert.mode", "false")
        );
    }

    public String getTableName() {
        return tableName;
    }

    public int getWriteParallelism() {
        return writeParallelism;
    }

    public boolean isUpsertMode() {
        return upsertMode;
    }

    @Override
    public String toString() {
        return "IcebergConfig{" +
                "tableName='" + tableName + '\'' +
                ", writeParallelism=" + writeParallelism +
                ", upsertMode=" + upsertMode +
                '}';
    }
}
