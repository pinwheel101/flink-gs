package com.flink.streaming.catalog;

import com.flink.streaming.config.CatalogConfig;
import org.apache.hadoop.conf.Configuration;
import org.apache.iceberg.catalog.Catalog;
import org.apache.iceberg.hive.HiveCatalog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Provider for Hive Metastore based Iceberg catalog.
 */
public class HiveCatalogProvider {
    private static final Logger LOG = LoggerFactory.getLogger(HiveCatalogProvider.class);
    private final CatalogConfig config;

    public HiveCatalogProvider(CatalogConfig config) {
        this.config = config;
    }

    public Catalog create() {
        LOG.info("Creating Hive catalog with metastore URI: {}", config.getHiveMetastoreUri());

        Configuration hadoopConf = new Configuration();
        hadoopConf.set("hive.metastore.uris", config.getHiveMetastoreUri());

        // Set warehouse location
        if (config.getWarehouse() != null) {
            hadoopConf.set("hive.metastore.warehouse.dir", config.getWarehouse());
        }

        Map<String, String> properties = new HashMap<>();
        properties.put("type", "hive");
        properties.put("uri", config.getHiveMetastoreUri());
        properties.put("warehouse", config.getWarehouse());
        properties.put("clients", "5");

        HiveCatalog catalog = new HiveCatalog();
        catalog.setConf(hadoopConf);
        catalog.initialize(config.getName(), properties);

        LOG.info("Hive catalog created successfully: {}", config.getName());
        return catalog;
    }
}
