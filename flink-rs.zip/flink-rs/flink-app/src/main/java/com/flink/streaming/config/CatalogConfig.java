package com.flink.streaming.config;

import java.util.Properties;

/**
 * Catalog configuration for Iceberg.
 */
public class CatalogConfig {
    public enum CatalogType {
        HIVE, REST
    }

    private final CatalogType type;
    private final String name;
    private final String warehouse;
    private final String database;

    // Hive-specific
    private final String hiveMetastoreUri;
    private final String hiveConfDir;

    // REST-specific
    private final String restUri;
    private final String restCredential;
    private final String restWarehouse;

    public CatalogConfig(Properties properties) {
        String typeStr = properties.getProperty("catalog.type", "hive");
        this.type = CatalogType.valueOf(typeStr.toUpperCase());
        this.name = properties.getProperty("catalog.name", "iceberg_catalog");
        this.warehouse = properties.getProperty("catalog.warehouse");
        this.database = properties.getProperty("catalog.database", "default");

        // Hive-specific configuration
        this.hiveMetastoreUri = properties.getProperty("hive.metastore.uri");
        this.hiveConfDir = properties.getProperty("hive.conf.dir", "/etc/hive/conf");

        // REST-specific configuration
        this.restUri = properties.getProperty("rest.catalog.uri");
        this.restCredential = properties.getProperty("rest.catalog.credential", "");
        this.restWarehouse = properties.getProperty("rest.catalog.warehouse", warehouse);
    }

    public CatalogType getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public String getDatabase() {
        return database;
    }

    public String getHiveMetastoreUri() {
        return hiveMetastoreUri;
    }

    public String getHiveConfDir() {
        return hiveConfDir;
    }

    public String getRestUri() {
        return restUri;
    }

    public String getRestCredential() {
        return restCredential;
    }

    public String getRestWarehouse() {
        return restWarehouse;
    }

    public boolean isHiveCatalog() {
        return type == CatalogType.HIVE;
    }

    public boolean isRestCatalog() {
        return type == CatalogType.REST;
    }

    @Override
    public String toString() {
        return "CatalogConfig{" +
                "type=" + type +
                ", name='" + name + '\'' +
                ", warehouse='" + warehouse + '\'' +
                ", database='" + database + '\'' +
                (type == CatalogType.HIVE ? ", hiveMetastoreUri='" + hiveMetastoreUri + '\'' : "") +
                (type == CatalogType.REST ? ", restUri='" + restUri + '\'' : "") +
                '}';
    }
}
