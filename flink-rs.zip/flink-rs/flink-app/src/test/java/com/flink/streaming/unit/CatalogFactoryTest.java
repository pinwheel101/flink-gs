package com.flink.streaming.unit;

import com.flink.streaming.catalog.CatalogFactory;
import com.flink.streaming.config.CatalogConfig;
import org.apache.iceberg.catalog.Catalog;
import org.junit.jupiter.api.Test;

import java.util.Properties;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for CatalogFactory.
 */
public class CatalogFactoryTest {

    @Test
    public void testHiveCatalogCreation() {
        Properties props = new Properties();
        props.setProperty("catalog.type", "hive");
        props.setProperty("catalog.name", "test_catalog");
        props.setProperty("catalog.warehouse", "file:///tmp/warehouse");
        props.setProperty("catalog.database", "default");
        props.setProperty("hive.metastore.uri", "thrift://localhost:9083");

        CatalogConfig config = new CatalogConfig(props);

        assertEquals(CatalogConfig.CatalogType.HIVE, config.getType());
        assertTrue(config.isHiveCatalog());
        assertFalse(config.isRestCatalog());
        assertEquals("test_catalog", config.getName());
        assertEquals("thrift://localhost:9083", config.getHiveMetastoreUri());
    }

    @Test
    public void testRestCatalogCreation() {
        Properties props = new Properties();
        props.setProperty("catalog.type", "rest");
        props.setProperty("catalog.name", "test_rest_catalog");
        props.setProperty("catalog.warehouse", "s3://warehouse");
        props.setProperty("catalog.database", "default");
        props.setProperty("rest.catalog.uri", "http://localhost:8181");
        props.setProperty("rest.catalog.credential", "test-token");

        CatalogConfig config = new CatalogConfig(props);

        assertEquals(CatalogConfig.CatalogType.REST, config.getType());
        assertFalse(config.isHiveCatalog());
        assertTrue(config.isRestCatalog());
        assertEquals("test_rest_catalog", config.getName());
        assertEquals("http://localhost:8181", config.getRestUri());
        assertEquals("test-token", config.getRestCredential());
    }

    @Test
    public void testCatalogConfigDefaults() {
        Properties props = new Properties();
        props.setProperty("catalog.warehouse", "file:///tmp/warehouse");

        CatalogConfig config = new CatalogConfig(props);

        assertEquals(CatalogConfig.CatalogType.HIVE, config.getType());
        assertEquals("iceberg_catalog", config.getName());
        assertEquals("default", config.getDatabase());
    }
}
