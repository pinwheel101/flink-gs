package com.flink.streaming.unit;

import com.flink.streaming.avro.Event;
import com.flink.streaming.avro.EventType;
import com.flink.streaming.transform.DefaultTransformation;
import com.flink.streaming.transform.TransformationPipeline;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.data.RowData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for transformation pipeline.
 */
public class TransformationTest {

    private StreamExecutionEnvironment env;
    private TransformationPipeline transformation;

    @BeforeEach
    public void setup() {
        env = StreamExecutionEnvironment.getExecutionEnvironment();
        transformation = new DefaultTransformation();
    }

    @Test
    public void testTransformationName() {
        assertEquals("DefaultTransformation", transformation.getName());
    }

    @Test
    public void testTransformationCreation() {
        assertNotNull(transformation);
        assertTrue(transformation instanceof DefaultTransformation);
    }

    @Test
    public void testCreateEvent() {
        Event.Builder builder = Event.newBuilder();
        builder.setEventId("test-123");
        builder.setTimestamp(System.currentTimeMillis());
        builder.setUserId("user-1");
        builder.setEventType(EventType.PAGE_VIEW);

        Map<CharSequence, CharSequence> payload = new HashMap<>();
        payload.put("page", "/home");
        builder.setPayload(payload);

        Event event = builder.build();

        assertNotNull(event);
        assertEquals("test-123", event.getEventId().toString());
        assertEquals("user-1", event.getUserId().toString());
        assertEquals(EventType.PAGE_VIEW, event.getEventType());
    }

    @Test
    public void testTransformationWithValidData() {
        // Create a test event
        Event event = Event.newBuilder()
                .setEventId("test-123")
                .setTimestamp(System.currentTimeMillis())
                .setUserId("user-1")
                .setEventType(EventType.CLICK)
                .setPayload(new HashMap<>())
                .build();

        // Create data stream
        DataStream<Event> eventStream = env.fromElements(event);

        // Apply transformation
        DataStream<RowData> result = transformation.transform(eventStream);

        assertNotNull(result);
    }
}
